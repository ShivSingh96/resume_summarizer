# setup.py
from setuptools import setup, find_packages

setup(
    name="resume_summarizer",
    version="0.1",
    packages=find_packages(),
    install_requires=[
        "requests",
        "python-docx",
        "PyMuPDF",
        "setuptools"
    ],
    entry_points={
        "console_scripts": [
            "resume_summarizer = resume_summarizer.cli:main"
        ]
    },
    author="Shivendra Kumar",
    description="CLI tool to summarize resumes using Ollama models",
    python_requires='>=3.8',
)

